---@meta

---@class cc.TransitionZoomFlipX :cc.TransitionSceneOriented
local TransitionZoomFlipX = {}
cc.TransitionZoomFlipX = TransitionZoomFlipX

---@overload fun(float:float,cc.Scene:cc.Scene):self
---@overload fun(float:float,cc.Scene:cc.Scene,int:int):self
---@param t float
---@param s cc.Scene
---@param o int
---@return self
function TransitionZoomFlipX:create(t, s, o) end
---*
---@return self
function TransitionZoomFlipX:TransitionZoomFlipX() end
