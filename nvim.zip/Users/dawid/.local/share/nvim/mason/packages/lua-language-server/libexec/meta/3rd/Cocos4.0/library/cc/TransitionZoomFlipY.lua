---@meta

---@class cc.TransitionZoomFlipY :cc.TransitionSceneOriented
local TransitionZoomFlipY = {}
cc.TransitionZoomFlipY = TransitionZoomFlipY

---@overload fun(float:float,cc.Scene:cc.Scene):self
---@overload fun(float:float,cc.Scene:cc.Scene,int:int):self
---@param t float
---@param s cc.Scene
---@param o int
---@return self
function TransitionZoomFlipY:create(t, s, o) end
---*
---@return self
function TransitionZoomFlipY:TransitionZoomFlipY() end
