---@meta

---@class cc.TMXTilesetInfo :cc.Ref
local TMXTilesetInfo = {}
cc.TMXTilesetInfo = TMXTilesetInfo

---*
---@param gid unsigned_int
---@return rect_table
function TMXTilesetInfo:getRectForGID(gid) end
---* js ctor
---@return self
function TMXTilesetInfo:TMXTilesetInfo() end
